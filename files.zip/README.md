# 📦 Containerised CRUD REST API

> **Assignment 2P-1 · Cloud & DevOps · April 2026**
> A production-ready REST API with full CRUD functionality, containerised with Docker and orchestrated via Docker Compose.

---

## 📌 Project Description

This project implements a **RESTful web service** that exposes complete **Create, Read, Update, Delete (CRUD)** operations over two resources — **Items** and **Users** — backed by a PostgreSQL database. Every service runs in its own isolated Docker container, connected through defined Docker networks, and managed by a single top-level `compose.yaml` file.

### Architecture

```
┌─────────────────────────────────────────────────┐
│                    Host Machine                  │
│  Port 80                                         │
│    │                                             │
│  ┌─▼──────────────┐   frontend   ┌────────────┐  │
│  │  nginx:80      │─────network──▶  api:3000  │  │
│  │  (Reverse Proxy│              │  (Node.js) │  │
│  └────────────────┘              └─────┬──────┘  │
│                                        │ backend  │
│                                        │ network  │
│                                  ┌─────▼──────┐  │
│                                  │  db:5432   │  │
│                                  │ (PostgreSQL│  │
│                                  │  + volume) │  │
│                                  └────────────┘  │
└─────────────────────────────────────────────────┘
```

### Containers / Services

| Container | Image | Role |
|---|---|---|
| `crud_nginx` | `nginx:1.25-alpine` | Reverse proxy, routes port 80 → API |
| `crud_api` | Custom (Node.js 20 Alpine) | Express REST API |
| `crud_db` | `postgres:16-alpine` | Persistent data store |

### Key Features

- Full **CRUD** on `/api/items` and `/api/users`
- **Nginx** reverse proxy in front of the API
- **Isolated Docker networks** — DB is not exposed to the host
- **Named volume** for database persistence across restarts
- **Health checks** on all three containers
- **Multi-stage Dockerfile** for a lean API image
- **Seed data** auto-loaded on first run

---

## 🗂 Project Structure

```
crud-api/
├── compose.yaml              # Docker Compose orchestration (top-level)
├── .env.example              # Environment variable template
├── .gitignore
├── postman_collection.json   # Importable Postman collection
│
├── api/                      # Node.js REST API service
│   ├── Dockerfile            # Multi-stage build
│   ├── .dockerignore
│   ├── package.json
│   └── server.js             # Express app with all routes
│
├── db-init/
│   └── init.sql              # Schema + seed data (auto-runs on first start)
│
└── nginx/
    └── default.conf          # Reverse proxy config
```

---

## 🚀 Running the Application

### Prerequisites

- [Docker](https://docs.docker.com/get-docker/) ≥ 24
- [Docker Compose](https://docs.docker.com/compose/) ≥ 2.20 (ships with Docker Desktop)

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/crud-api.git
cd crud-api

# 2. Create environment file
cp .env.example .env
#    Edit .env if you want to change DB credentials

# 3. Build and start all containers
docker compose up --build -d

# 4. Verify all containers are healthy
docker compose ps

# 5. Test the API
curl http://localhost/health
curl http://localhost/api/items
```

### Stopping

```bash
docker compose down          # stop + remove containers, keep volume
docker compose down -v       # stop + remove containers AND data volume
```

### Rebuilding after code changes

```bash
docker compose up --build -d api
```

---

## 🔗 API Endpoints

Base URL: `http://localhost`

### Health

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | API info & endpoint list |
| GET | `/health` | Service + DB health status |

### Items `/api/items`

| Method | Endpoint | Description | Required Body |
|---|---|---|---|
| GET | `/api/items` | List all items | — |
| GET | `/api/items/:id` | Get single item | — |
| POST | `/api/items` | Create item | `name` |
| PUT | `/api/items/:id` | Update item (partial) | any field |
| DELETE | `/api/items/:id` | Delete item | — |

**Item fields:** `name`, `description`, `price`, `quantity`

### Users `/api/users`

| Method | Endpoint | Description | Required Body |
|---|---|---|---|
| GET | `/api/users` | List all users | — |
| GET | `/api/users/:id` | Get single user | — |
| POST | `/api/users` | Create user | `name`, `email` |
| PUT | `/api/users/:id` | Update user (partial) | any field |
| DELETE | `/api/users/:id` | Delete user | — |

**User fields:** `name`, `email`, `role` (`admin` \| `user` \| `moderator`)

### Example Requests

```bash
# Create an item
curl -X POST http://localhost/api/items \
  -H "Content-Type: application/json" \
  -d '{"name":"Headphones","price":199.99,"quantity":30}'

# Update an item
curl -X PUT http://localhost/api/items/1 \
  -H "Content-Type: application/json" \
  -d '{"price":149.99}'

# Delete an item
curl -X DELETE http://localhost/api/items/1

# Create a user
curl -X POST http://localhost/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Doe","email":"jane@example.com","role":"admin"}'
```

---

## 📮 Postman Collection

Import `postman_collection.json` (included in this repo) directly into Postman:

1. Open Postman → **Import** → drag-drop `postman_collection.json`
2. The base URL is pre-set to `http://localhost`
3. All 12 requests are ready to run

> **Online Collection Link:** _(Publish your collection and paste the public share link here, e.g. `https://www.postman.com/<user>/collection/<id>`)_

---

## 🐳 Docker Hub

The API image is available publicly on Docker Hub:

> **Image:** `docker.io/<your-dockerhub-username>/crud-api:latest`

```bash
# Pull the pre-built image
docker pull <your-dockerhub-username>/crud-api:latest
```

To use the pre-built image instead of building locally, replace the `build` block in `compose.yaml` with:

```yaml
api:
  image: <your-dockerhub-username>/crud-api:latest
```

### Pushing your own image

```bash
docker build -t <your-dockerhub-username>/crud-api:latest ./api
docker push <your-dockerhub-username>/crud-api:latest
```

---

## 🌍 Environment Variables

| Variable | Default | Description |
|---|---|---|
| `POSTGRES_DB` | `cruddb` | Database name |
| `POSTGRES_USER` | `postgres` | DB username |
| `POSTGRES_PASSWORD` | `postgres` | DB password |

Set these in your `.env` file (copied from `.env.example`).

---

## 🧪 Useful Commands

```bash
# View live logs for all services
docker compose logs -f

# View logs for a specific service
docker compose logs -f api

# Shell into the API container
docker exec -it crud_api sh

# Shell into the database
docker exec -it crud_db psql -U postgres -d cruddb

# Check container resource usage
docker stats
```

---

## 🏗 Tech Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 20 (Alpine) |
| Framework | Express.js 4 |
| Database | PostgreSQL 16 (Alpine) |
| Proxy | Nginx 1.25 (Alpine) |
| Containerisation | Docker + Docker Compose v2 |

---

## 👨‍💻 Author

**Your Name**
Cloud & DevOps · Assignment 2P-1 · April 2026

---

## 📄 License

MIT
